# Relatório Zonas GeoJSON

Este pacote junta pontos a zonas usando segmentos cartesianos em longitude e
latitude, com predicados racionais exatos sobre os decimais fornecidos. Não é um
geocodificador, cadastro territorial ou cálculo de distância/área real. Não usa
rede, modelos ou contas. O exemplo distribuído contém dados autorais sintéticos;
não representa endereços ou jurisdições reais.

`resultado.json` ordena pontos e zonas por ID. `inside` significa uma única zona
no interior; `boundary`, uma única zona na borda (inclusive a borda de um furo);
`ambiguous`, duas ou mais correspondências; `outside`, nenhuma. Nenhuma zona é
escolhida como vencedora. Um ponto em furo fica fora, salvo na própria borda.
`pointsWithBoundary` também inclui pontos ambíguos que tocam alguma borda.

`pontos.geojson` e `zonas.geojson` preservam os bytes das entradas. O GeoJSON
anotado preserva ordem, propriedades e valores das coordenadas, acrescentando
cinco campos `zg_`. `zg_matches` é uma string JSON compacta: decodifique-a
explicitamente para obter a lista de zonas e relações. O CSV cria uma linha por
correspondência e uma linha para cada ponto externo. IDs com =, +, - ou @ após
espaços recebem apóstrofo no CSV para reduzir interpretação como fórmula;
os IDs originais permanecem no JSON. Números permanecem exatos no JSON/CSV.
Consumidores GIS que convertem coordenadas para float podem perder precisão.

`mapa.svg` é uma figura estática sem recursos externos. A vista arredonda apenas
as posições de desenho a seis casas; a classificação não usa esse desenho.
Furos usam evenodd. Cores e formas identificam status. Até 40 IDs são rotulados;
todos constam nos títulos SVG. IDs longos são abreviados apenas nos rótulos;
U+FFFE/U+FFFF aparecem como string JSON ASCII escapada no SVG por restrição
do XML 1.0. Dimensões de viewport não são distâncias.

O orçamento `work.limit` inclui um check por interseção de segmentos e por
segmento examinado na localização de ponto, durante validação e junção. Bbox
rejeitadas não consomem checks. Ao exceder o orçamento ou 100000 matches não há
resultado parcial. Não se promete limite absoluto de tempo ou RAM.

Recorte: Point 2D, Polygon e MultiPolygon, esquema fechado, até 10000 pontos,
100 zonas e 5000 vértices; 1000 posições por anel e 64 furos por polígono.
Anéis devem ser simples e fechados; furos e componentes devem ficar separados.
Antimeridiano/span de anel >= 180 graus não é suportado. Coordenadas têm até
18 casas decimais normalizadas. JSON UTF-8 sem BOM/duplicatas: até 8 MiB
originais e canônicos, profundidade 16 e 200000 nós. Veja a documentação do
formato para os limites numéricos completos e o significado da exatidão.

`manifesto.json` lista SHA-256 e tamanho dos outros sete arquivos. O ZIP tem
nomes fixos, ordem lexicográfica, data 1980-01-01 e permissões 0644. A saída é
publicada exclusivamente: destino existente nunca é sobrescrito.
